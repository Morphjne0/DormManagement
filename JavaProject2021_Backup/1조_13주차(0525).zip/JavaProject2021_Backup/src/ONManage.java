import javax.swing.*;

public class ONManage extends JPanel {
    ONManage(){

    }
}
