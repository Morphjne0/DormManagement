import javax.swing.*;
import java.awt.*;

public class StdTab extends JPanel  {
    StdTab STab;
    StdMenu Stdmenu;
    CenterPanel cenP;

    void viewP(JPanel p){
        remove(cenP);
        add(p, BorderLayout.CENTER);
        revalidate();
    }
    public StdTab() {
        setLayout(new BorderLayout());
        cenP= new CenterPanel();
    add(cenP,BorderLayout.CENTER);
    }
}
