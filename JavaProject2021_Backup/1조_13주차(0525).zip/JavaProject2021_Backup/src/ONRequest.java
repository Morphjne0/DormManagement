import javax.swing.*;

public class ONRequest extends JPanel {
}
