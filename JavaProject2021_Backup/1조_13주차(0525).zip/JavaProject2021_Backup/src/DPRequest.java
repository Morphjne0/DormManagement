import javax.swing.*;

public class DPRequest extends JPanel {
}
