import javax.swing.*;

public class Logout extends JPanel {
}
