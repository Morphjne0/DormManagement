import javax.swing.*;

public class aa11 {
    private JPanel panel1;
    private JPanel panel2;
    private JTextField 검색TextField;
    private JButton SearchB;

    private void createUIComponents() {
        // TODO: place custom component creation code here
    }
}
