import javax.swing.*;
import java.awt.*;

public class DPManage extends JPanel {
    DPManage(){

        setLayout(null);
        ImageIcon img = new ImageIcon();
        JLabel picture = new JLabel(img);
        JPanel contentPane = new JPanel();
        this.setVisible(true);


        JPanel panel_1 = new JPanel();
        panel_1.setBackground(Color.RED);
        panel_1.setBounds(769, 18, 850, 955);
        add(panel_1);

        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setToolTipText("");
        scrollPane.setBounds(56, 18, 601, 955);
        add(scrollPane);
    }
}

