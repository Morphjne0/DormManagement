import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

public class DormManagementDAO{
    Connection conn = null;
    Statement stmt = null;
    ResultSet rs = null;
    DormManager DM;
    //ManageTab MngTab=ManageTab.getInstance();
    StdMenu stdMenu;
    Login login;
    Data data;
    String name,sid,dept,roomNumb,pNumb,sex,pic;


    static DormManagementDAO instance=null;

    String url = "jdbc:mysql://localhost:3306/Dormdb?serverTimezone=Asia/Seoul";
    String id = "root";
    String pwd = "1234";


    public DormManagementDAO(){

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            System.out.println("드라이버 로딩됨/requestRead");
            conn = DriverManager.getConnection(url,id,pwd);
            System.out.println("DB 연결 완료/requestWrite");
            stmt = conn.createStatement();
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }

    }
    public ArrayList<Data> getList() {
        ArrayList<Data> Datalist = new ArrayList<Data>();
        System.out.println("1111");
        try {
            System.out.println("1111");
            String sql = "select r_Number,dept,s_ID,s_name,P_number,sex from studentTBl";
            stmt = conn.createStatement();
            rs =stmt.executeQuery(sql);

            while(rs.next()) {
                roomNumb = rs.getString("r_Number");
                dept = rs.getString("dept");
                sid = rs.getString("s_iD");
                name = rs.getString("s_name");
                pNumb = rs.getString("P_number");
                sex = rs.getString("sex");

                Data d = new Data(roomNumb,dept,sid,name,pNumb,sex);

                Datalist.add(d);
            }


        } catch (SQLException e) {
            System.out.println("DB 연결 오류");
            e.printStackTrace();
        }

        return Datalist;
    }
    void DormManage(){
        try{
            String sql = "select r_Number,dept,s_ID,s_name,P_number,sex from studentTBl";
            stmt = conn.createStatement();
            rs= stmt.executeQuery(sql);

            while (rs.next()) {
                roomNumb = rs.getString("r_Number");
                dept = rs.getString("dept");
                sid = rs.getString("s_iD");
                name = rs.getString("s_name");
                pNumb = rs.getString("P_number");
                sex = rs.getString("sex");

            }
            } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        }
    void Picture(){
        try{
            String sql= "select pic from studentTable where s_name = '" + id + "' and s_id = '"+sid+"'";
            stmt = conn.createStatement();
            rs= stmt.executeQuery(sql);
            while(rs.next()){
                pic=rs.getString("pic");
            }
        }catch (SQLException throwables){
            throwables.printStackTrace();
        }

    }

    void StdManagement(){
        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            System.out.println("=========================================================");
            System.out.println("드라이버 로딩됨");

        } catch (ClassNotFoundException e) {
            System.out.println("=========================================================");
            System.out.println("드라이버 로딩 실패");

            e.printStackTrace();
        }
        try {
            conn = DriverManager.getConnection(url,id,pwd);
            System.out.println("=========================================================");
            System.out.println("DB 연결 완료");

            String sql = "select * from stdtbl";
            stmt = conn.createStatement();
            rs= stmt.executeQuery(sql);

            while (rs.next()){
                //db내용 불러오기작성
            }

        } catch (SQLException e) {
            System.out.println("=========================================================");
            System.out.println("DB 연결 오류");

            e.printStackTrace();
        }
    }
    void requestWrite(){
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            System.out.println("드라이버 로딩됨/requestWrite");

        } catch (ClassNotFoundException e) {
            System.out.println("드라이버 로딩 실패/requestWrite");
            e.printStackTrace();
        }
        try {
            conn = DriverManager.getConnection(url,id,pwd);
            System.out.println("DB 연결 완료/requestWrite");
        } catch (SQLException e) {
            System.out.println("DB 연결 오류/requestWrite");
            e.printStackTrace();
        }
    }
    void requestManage(){
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            System.out.println("드라이버 로딩됨/requestRead");
        } catch (ClassNotFoundException e) {
            System.out.println("드라이버 로딩 실패/requestRead");
            e.printStackTrace();
        }
        try {
            conn = DriverManager.getConnection(url,id,pwd);
            System.out.println("DB 연결 완료/requestWrite");
        } catch (SQLException e) {
            System.out.println("드라이버 로딩 실패/requestRead");
            e.printStackTrace();
        }
    }
    boolean login(String id,String pw){
        try {
            String sql = "select s_name, s_id from studentTBl where s_name = '" + id + "' and s_id = '"+pw+"'";

            rs = stmt.executeQuery(sql);
            rs.next();
            if(rs.getString("s_name").equals(null)){
                return false;
            }else{
                return true;
            }

//                if (name&&sid != null) {
//                    CenterP.LoginBtn.setVisible(false);
//                    DM.stdMenu.setVisible(true);
//                }else{
//                JOptionPane.showMessageDialog(CenterP, "로그인 실패", "경고", JOptionPane.WARNING_MESSAGE);
//            }

        } catch (SQLException e) {
            System.out.println("드라이/버 로딩 실패/requestRead");
            e.printStackTrace();
            return false;
        }
    }


    void disconnect(){
        if (conn != null){
            try {
                conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        if(stmt!= null){
            try {
                stmt.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        System.out.println("=========================================================");
        System.out.println("DB 연결 해제");
    }


    static DormManagementDAO getInstance() throws NullPointerException{
            if(instance==null){instance=new DormManagementDAO();}
        return instance;
    }

}
