import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

public class CenterPanel extends JPanel {
    JButton LoginBtn;
    Login login;
    CenterPanel centerP;
    JTextField id;
    JPasswordField pw;
    String idText;
    String pwText;
    Menu menu;
    DormManager DM;
    DormManagementDAO DAO;
    static CenterPanel instance=null;
    public CenterPanel() {

        setLayout(null);
        ImageIcon img = new ImageIcon("img/symbol.png");
        JLabel logo = new JLabel(img);

        Font f1 = new Font("나눔스퀘어 Bold", Font.PLAIN, 30);
        logo.setBounds(585, 210, 500, 500);
        add(logo);
        //Color color = new Color(0x66FFCC);
        Color color = new Color(0xDCD3B7);//0xC8000000,0xABE4EC,0xDCD3B7
        setBackground(color);
        LoginBtn = new JButton("로그인");
        id= new JTextField("admin");
        pw= new JPasswordField("kopo2021@");
        LoginBtn.setFont(f1);
        id.setBounds(700, 600, 270, 40);
        pw.setBounds(700, 650, 270, 40);
        LoginBtn.setBounds(700, 700, 270, 63);

            class mouseListener implements MouseListener{
                @Override
                public void mouseClicked(MouseEvent e) {

                }
                @Override
                public void mouseEntered(MouseEvent e) {
                }
                @Override
                public void mouseExited(MouseEvent e) {
                }
                @Override
                public void mousePressed(MouseEvent e) {

                }

                @Override
                public void mouseReleased(MouseEvent e) {

                }
            }
        }
        /*
    static CenterPanel getInstance(){
        try {
            if(instance==null){instance=new CenterPanel();}
        }catch (NullPointerException e){}
        return instance;
    }
         */
    }

