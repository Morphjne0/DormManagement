import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumnModel;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;
import java.util.Vector;

public class ManageTab extends JPanel {
    String search;
    Data d;
    DefaultTableModel model;
    static ManageTab instance=null;
    Object ob[][]=new Object[0][6];
    DormManagementDAO dao = DormManagementDAO.getInstance();
    JTable table;
    String header[]= {"방번호"," 학 과 ","  학 번  ","이 름"," 전 화 번 호 ","성 별"};
    //ArrayList<Data> dataArrayList = new ArrayList<Data>();

    public ManageTab(){

        setLayout(null);
        ImageIcon img = new ImageIcon();
        JLabel picture = new JLabel(img);
        JPanel listP = new JPanel();

        model=new DefaultTableModel(header,0);
        table = new JTable(model);
        table.getTableHeader().setReorderingAllowed(false);
        table.getTableHeader().setResizingAllowed(false);
        JScrollPane scrollPane = new JScrollPane(table);
        table.getColumn("방번호").setPreferredWidth(10);
        this.setVisible(true);
        scrollPane.setBounds(38, 18, 804,950);
        scrollPane.setPreferredSize(new Dimension(200,200));
        scrollPane.setVisible(true);

        DefaultTableCellRenderer tScheduleCellRenderer = new DefaultTableCellRenderer();
        tScheduleCellRenderer.setHorizontalAlignment(SwingConstants.CENTER);
        TableColumnModel tcmSchedule = table.getColumnModel();
        for (int i = 0; i < tcmSchedule.getColumnCount(); i++) {
            tcmSchedule.getColumn(i).setCellRenderer(tScheduleCellRenderer);
        }

        ArrayList<Data> dataArrayList = dao.getList();
        for(Data d:dataArrayList) {
            Vector<String>v=new Vector<String>();
            v.add(d.getRoomNumb());
            v.add(d.getDept());
            v.add(d.getSid());
            v.add(d.getName());
            v.add(d.getpNumb());
            v.add(d.getSex());
            model.addRow(v);
        }


       // table.updateUI();
//---------------------여기까지 작업(테이블 세부조정중이었음)-------------------------------------------------------------
        scrollPane.setBackground(Color.CYAN);

        add(scrollPane);

        JPanel panel = new JPanel();
        panel.setBackground(Color.YELLOW);
        panel.setBounds(908, 18, 407, 359);
        add(panel);
        JLabel l1= new JLabel("방번호");
        JLabel l2= new JLabel("학과");
        JLabel l3= new JLabel("학번");
        JLabel l4= new JLabel("이름");
        JLabel l5= new JLabel("전화번호");
        JLabel l6= new JLabel("성별");
        l1.setBounds(50,200,50,50);
        panel.add(l1);
        JLabel lblNewLabel = new JLabel("간략정보");
        panel.add(lblNewLabel);

        JPanel panel_1 = new JPanel();
        panel_1.setBackground(Color.GREEN);
        panel_1.setBounds(1315, 18, 257, 359);
        add(panel_1);

        JLabel lblNewLabel_2 = new JLabel("이미지");
        panel_1.add(lblNewLabel_2);

        JPanel panel_2 = new JPanel();
        panel_2.setBackground(Color.RED);
        panel_2.setBounds(908, 373, 664, 487);
        add(panel_2);

        JLabel lblNewLabel_1 = new JLabel("세부정보");
        panel_2.add(lblNewLabel_1);

        JPanel panel_3 = new JPanel();
        panel_3.setBackground(Color.GREEN);
        panel_3.setBounds(908, 18, 664, 841);
        add(panel_3);
        table.addMouseListener(new ML());
        revalidate();
        }
    class ML implements MouseListener {
        public void mousePressed(MouseEvent e){

        }
        public void mouseClicked(MouseEvent e){

            int srow=table.getSelectedRow();
            String name=(String)
                    table.getValueAt(srow,0);
            String tel=(String)
                    table.getValueAt(srow,1);
           // tf1.setText(name);//클릭하면
          //  tf2.setText(tel);
            revalidate();
        }
        public void mouseReleased(MouseEvent e){

        }

        @Override
        public void mouseEntered(MouseEvent e) {

        }

        public void mouseExited(MouseEvent e){
        }


    }

    static ManageTab getInstance(){
        try {
            if(instance==null){instance=new ManageTab();}
        }catch (NullPointerException e){}
        return instance;
    }
}
